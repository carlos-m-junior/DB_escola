import sqlite3
from tkinter import *
from tkinter import messagebox

# Conectar ao banco de dados SQLite (ou criar, se não existir)
conn = sqlite3.connect('cidades.db')
cursor = conn.cursor()

# Criar a tabela 'cidades', caso ainda não exista
cursor.execute('''
CREATE TABLE IF NOT EXISTS cidades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    estado TEXT NOT NULL
)
''')
conn.commit()

# Função para adicionar uma cidade no banco de dados
def adicionar_cidade():
    nome = entry_nome.get()
    estado = entry_estado.get()

    if nome and estado:
        cursor.execute("INSERT INTO cidades (nome, estado) VALUES (?, ?)", (nome, estado))
        conn.commit()
        messagebox.showinfo("Sucesso", "Cidade adicionada com sucesso!")
        entry_nome.delete(0, END)
        entry_estado.delete(0, END)
        carregar_cidades()
    else:
        messagebox.showwarning("Erro", "Preencha todos os campos.")

# Função para carregar as cidades do banco de dados
def carregar_cidades():
    cursor.execute("SELECT * FROM cidades")
    registros = cursor.fetchall()

    # Limpar a lista antes de atualizar
    listbox_cidades.delete(0, END)

    for registro in registros:
        listbox_cidades.insert(END, f"ID: {registro[0]} | Nome: {registro[1]} | Estado: {registro[2]}")

# Criar janela principal
janela = Tk()
janela.title("Cadastro de Cidades")

# Elementos da interface gráfica
Label(janela, text="Nome da Cidade:").grid(row=0, column=0)
entry_nome = Entry(janela)
entry_nome.grid(row=0, column=1)

Label(janela, text="Estado:").grid(row=1, column=0)
entry_estado = Entry(janela)
entry_estado.grid(row=1, column=1)

botao_adicionar = Button(janela, text="Adicionar Cidade", command=adicionar_cidade)
botao_adicionar.grid(row=2, column=0, columnspan=2)

# Lista para exibir as cidades
listbox_cidades = Listbox(janela, width=50)
listbox_cidades.grid(row=3, column=0, columnspan=2)

# Carregar as cidades na lista ao iniciar
carregar_cidades()

# Iniciar o loop da interface gráfica
janela.mainloop()

# Fechar a conexão com o banco de dados ao sair
conn.close()
