import tkinter as tk
from tkinter import messagebox
import mysql.connector


# Função para inserir dados no banco de dados
def inserir_aluno():
    nome = nome_entry.get()
    data_nascimento = data_nascimento_entry.get()
    id_cidade = id_cidade_entry.get()

    if nome and data_nascimento:
        try:
            # Conectar ao banco de dados MySQL
            conexao = mysql.connector.connect(
                host="localhost",  # Substitua pelo host do seu banco
                user="seu_usuario",  # Substitua pelo seu usuário do MySQL
                password="sua_senha",  # Substitua pela sua senha
                database="sua_base_de_dados"  # Substitua pelo nome do banco de dados
            )

            cursor = conexao.cursor()

            # Query de inserção
            query = "INSERT INTO alunos (nome, data_nascimento, id_cidade) VALUES (%s, %s, %s)"
            valores = (nome, data_nascimento, id_cidade)

            # Executar a query
            cursor.execute(query, valores)
            conexao.commit()

            messagebox.showinfo("Sucesso", "Aluno inserido com sucesso!")

        except mysql.connector.Error as err:
            messagebox.showerror("Erro", f"Erro ao inserir aluno: {err}")

        finally:
            # Fechar a conexão
            if conexao.is_connected():
                cursor.close()
                conexao.close()
    else:
        messagebox.showwarning("Atenção", "Preencha todos os campos!")


# Criar a interface gráfica
janela = tk.Tk()
janela.title("Cadastro de Alunos")

# Label e Entry para o nome
tk.Label(janela, text="Nome").grid(row=0, column=0)
nome_entry = tk.Entry(janela)
nome_entry.grid(row=0, column=1)

# Label e Entry para a data de nascimento
tk.Label(janela, text="Data de Nascimento (AAAA-MM-DD)").grid(row=1, column=0)
data_nascimento_entry = tk.Entry(janela)
data_nascimento_entry.grid(row=1, column=1)

# Label e Entry para o ID da cidade
tk.Label(janela, text="ID da Cidade").grid(row=2, column=0)
id_cidade_entry = tk.Entry(janela)
id_cidade_entry.grid(row=2, column=1)

# Botão para inserir o aluno
inserir_btn = tk.Button(janela, text="Inserir Aluno", command=inserir_aluno)
inserir_btn.grid(row=3, column=1)

# Iniciar o loop da interface gráfica
janela.mainloop()
