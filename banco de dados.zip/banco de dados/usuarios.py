import tkinter as tk
from tkinter import messagebox
import mysql.connector

# Configuração do banco de dados MySQL
db_config = {
    'host': 'localhost',
    'user': 'seu_usuario',
    'password': 'sua_senha',
    'database': 'seu_banco_de_dados'
}


# Função para conectar ao banco de dados
def get_db_connection():
    conn = mysql.connector.connect(**db_config)
    return conn


# Função para listar usuários
def listar_usuarios():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM usuarios")
    rows = cursor.fetchall()
    conn.close()

    lista.delete(0, tk.END)  # Limpa a lista de usuários
    for row in rows:
        lista.insert(tk.END, f"ID: {row[0]}, Nome: {row[1]}, Email: {row[2]}, Tipo: {row[4]}")


# Função para adicionar usuário
def adicionar_usuario():
    nome = entry_nome.get()
    email = entry_email.get()
    senha = entry_senha.get()
    tipo = entry_tipo.get()

    if nome and email and senha and tipo:
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO usuarios (nome, email, senha, tipo) VALUES (%s, %s, %s, %s)",
                           (nome, email, senha, tipo))
            conn.commit()
            messagebox.showinfo("Sucesso", "Usuário adicionado com sucesso!")
            listar_usuarios()  # Atualiza a lista de usuários
        except mysql.connector.Error as err:
            messagebox.showerror("Erro", f"Erro ao adicionar usuário: {err}")
        finally:
            conn.close()
    else:
        messagebox.showwarning("Entrada inválida", "Todos os campos são obrigatórios.")


# Função para criar a janela
def criar_janela():
    global entry_nome, entry_email, entry_senha, entry_tipo, lista

    # Janela principal
    root = tk.Tk()
    root.title("Gerenciador de Usuários")

    # Labels e entradas
    tk.Label(root, text="Nome").grid(row=0, column=0)
    entry_nome = tk.Entry(root)
    entry_nome.grid(row=0, column=1)

    tk.Label(root, text="Email").grid(row=1, column=0)
    entry_email = tk.Entry(root)
    entry_email.grid(row=1, column=1)

    tk.Label(root, text="Senha").grid(row=2, column=0)
    entry_senha = tk.Entry(root, show="*")
    entry_senha.grid(row=2, column=1)

    tk.Label(root, text="Tipo").grid(row=3, column=0)
    entry_tipo = tk.Entry(root)
    entry_tipo.grid(row=3, column=1)

    # Botão para adicionar usuário
    btn_add = tk.Button(root, text="Adicionar Usuário", command=adicionar_usuario)
    btn_add.grid(row=4, column=0, columnspan=2)

    # Lista de usuários
    lista = tk.Listbox(root, width=50)
    lista.grid(row=5, column=0, columnspan=2)

    # Botão para listar usuários
    btn_list = tk.Button(root, text="Listar Usuários", command=listar_usuarios)
    btn_list.grid(row=6, column=0, columnspan=2)

    # Inicia a janela
    root.mainloop()


# Executa a aplicação
criar_janela()
