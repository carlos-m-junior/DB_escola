import tkinter as tk
from tkinter import messagebox
import sqlite3

# Conectar ao banco de dados (usando SQLite para demonstração)
conn = sqlite3.connect('professores.db')
cursor = conn.cursor()

# Criar tabela se não existir (baseado na estrutura da tabela `professores`)
cursor.execute("""
CREATE TABLE IF NOT EXISTS professores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    especialidade TEXT NOT NULL,
    id_cidade INTEGER
)
""")
conn.commit()

# Função para inserir professor no banco de dados
def inserir_professor():
    nome = entry_nome.get()
    especialidade = entry_especialidade.get()
    id_cidade = entry_id_cidade.get()

    if nome and especialidade and (id_cidade.isdigit() or id_cidade == ""):
        cursor.execute("INSERT INTO professores (nome, especialidade, id_cidade) VALUES (?, ?, ?)",
                       (nome, especialidade, int(id_cidade) if id_cidade else None))
        conn.commit()
        messagebox.showinfo("Sucesso", "Professor inserido com sucesso!")
        entry_nome.delete(0, tk.END)
        entry_especialidade.delete(0, tk.END)
        entry_id_cidade.delete(0, tk.END)
        mostrar_professores()
    else:
        messagebox.showwarning("Erro", "Por favor, preencha todos os campos corretamente.")

# Função para mostrar os professores cadastrados
def mostrar_professores():
    cursor.execute("SELECT * FROM professores")
    registros = cursor.fetchall()

    # Limpar a listbox antes de exibir
    listbox_professores.delete(0, tk.END)

    # Inserir professores na listbox
    for professor in registros:
        listbox_professores.insert(tk.END, professor)

# Interface gráfica
root = tk.Tk()
root.title("Cadastro de Professores")

# Widgets para inserir dados
label_nome = tk.Label(root, text="Nome do Professor:")
label_nome.grid(row=0, column=0)
entry_nome = tk.Entry(root)
entry_nome.grid(row=0, column=1)

label_especialidade = tk.Label(root, text="Especialidade:")
label_especialidade.grid(row=1, column=0)
entry_especialidade = tk.Entry(root)
entry_especialidade.grid(row=1, column=1)

label_id_cidade = tk.Label(root, text="ID da Cidade:")
label_id_cidade.grid(row=2, column=0)
entry_id_cidade = tk.Entry(root)
entry_id_cidade.grid(row=2, column=1)

# Botão para inserir professor
button_inserir = tk.Button(root, text="Inserir Professor", command=inserir_professor)
button_inserir.grid(row=3, column=0, columnspan=2)

# Listbox para mostrar professores cadastrados
listbox_professores = tk.Listbox(root, width=50)
listbox_professores.grid(row=4, column=0, columnspan=2)

# Mostrar professores ao iniciar
mostrar_professores()

root.mainloop()

# Fechar conexão com banco de dados
conn.close()
