import tkinter as tk
from tkinter import messagebox


# Função para abrir a janela de gestão de alunos
def abrir_alunos():
    messagebox.showinfo("Alunos", "Abrindo gestão de alunos.")


# Função para abrir a janela de gestão de cursos
def abrir_cursos():
    messagebox.showinfo("Cursos", "Abrindo gestão de cursos.")


# Função para abrir a janela de gestão de cidades
def abrir_cidades():
    messagebox.showinfo("Cidades", "Abrindo gestão de cidades.")


# Função para abrir a janela de gestão de professores
def abrir_professores():
    messagebox.showinfo("Professores", "Abrindo gestão de professores.")


# Função para abrir a janela de gestão de usuários
def abrir_usuarios():
    messagebox.showinfo("Usuários", "Abrindo gestão de usuários.")


# Função para exibir o menu principal após login bem-sucedido
def exibir_menu():
    menu_janela = tk.Toplevel()
    menu_janela.title("Menu Principal")

    tk.Label(menu_janela, text="Selecione uma opção").pack(pady=10)

    btn_alunos = tk.Button(menu_janela, text="Gerenciar Alunos", command=abrir_alunos)
    btn_alunos.pack(pady=5)

    btn_cursos = tk.Button(menu_janela, text="Gerenciar Cursos", command=abrir_cursos)
    btn_cursos.pack(pady=5)

    btn_cidades = tk.Button(menu_janela, text="Gerenciar Cidades", command=abrir_cidades)
    btn_cidades.pack(pady=5)

    btn_professores = tk.Button(menu_janela, text="Gerenciar Professores", command=abrir_professores)
    btn_professores.pack(pady=5)

    btn_usuarios = tk.Button(menu_janela, text="Gerenciar Usuários", command=abrir_usuarios)
    btn_usuarios.pack(pady=5)


# Função para verificar o login
def verificar_login():
    usuario = entry_usuario.get()
    senha = entry_senha.get()

    # Exemplo de verificação
    if usuario == "admin" and senha == "senha123":
        messagebox.showinfo("Login", "Login bem-sucedido!")
        janela.withdraw()  # Esconde a janela de login
        exibir_menu()  # Exibe o menu principal
    else:
        messagebox.showerror("Login", "Usuário ou senha incorretos.")


# Criar a janela principal
janela = tk.Tk()
janela.title("Tela de Login")

# Criar widgets
label_usuario = tk.Label(janela, text="Usuário:")
label_usuario.pack(pady=5)

entry_usuario = tk.Entry(janela)
entry_usuario.pack(pady=5)

label_senha = tk.Label(janela, text="Senha:")
label_senha.pack(pady=5)

entry_senha = tk.Entry(janela, show="*")
entry_senha.pack(pady=5)

botao_login = tk.Button(janela, text="Login", command=verificar_login)
botao_login.pack(pady=20)

# Iniciar o loop da interface
janela.mainloop()
