import mysql.connector
from mysql.connector import errorcode

# Configurações de conexão
config = {
    'user': 'seu_usuario',           # Substitua pelo seu usuário
    'password': 'sua_senha',         # Substitua pela sua senha
    'host': 'localhost',
    'database': 'dbescola',
}

try:
    # Conectando ao banco de dados
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor()

    # Criando tabelas
    cursor.execute("DROP TABLE IF EXISTS `alunos`")
    cursor.execute("""
        CREATE TABLE `alunos` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `nome` varchar(100) NOT NULL,
          `data_nascimento` date NOT NULL,
          `id_cidade` int(11) DEFAULT NULL,
          PRIMARY KEY (`id`),
          KEY `id_cidade` (`id_cidade`)
        ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    """)

    cursor.execute("DROP TABLE IF EXISTS `cidades`")
    cursor.execute("""
        CREATE TABLE `cidades` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `nome` varchar(100) NOT NULL,
          `estado` varchar(100) NOT NULL,
          PRIMARY KEY (`id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    """)

    cursor.execute("DROP TABLE IF EXISTS `cursos`")
    cursor.execute("""
        CREATE TABLE `cursos` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `nome` varchar(100) NOT NULL,
          `duracao` int(11) NOT NULL,
          `id_cidade` int(11) DEFAULT NULL,
          PRIMARY KEY (`id`),
          KEY `id_cidade` (`id_cidade`)
        ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    """)

    cursor.execute("DROP TABLE IF EXISTS `professores`")
    cursor.execute("""
        CREATE TABLE `professores` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `nome` varchar(100) NOT NULL,
          `especialidade` varchar(100) NOT NULL,
          `id_cidade` int(11) DEFAULT NULL,
          PRIMARY KEY (`id`),
          KEY `id_cidade` (`id_cidade`)
        ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    """)

    cursor.execute("DROP TABLE IF EXISTS `usuarios`")
    cursor.execute("""
        CREATE TABLE `usuarios` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `nome` varchar(100) NOT NULL,
          `email` varchar(100) NOT NULL,
          `senha` varchar(255) NOT NULL,
          `tipo` enum('admin','professor','aluno') NOT NULL,
          PRIMARY KEY (`id`),
          UNIQUE KEY `email` (`email`)
        ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    """)

    # Inserindo dados nas tabelas
    cursor.execute("INSERT INTO `cidades` (nome, estado) VALUES ('Curitiba', 'PR')")
    cursor.execute("INSERT INTO `cidades` (nome, estado) VALUES ('Porto Alegre', 'RS')")
    cursor.execute("INSERT INTO `cidades` (nome, estado) VALUES ('Salvador', 'BA')")

    cursor.execute("INSERT INTO `cursos` (nome, duracao, id_cidade) VALUES ('Engenharia de Software', 48, 1)")
    cursor.execute("INSERT INTO `cursos` (nome, duracao, id_cidade) VALUES ('Administração', 36, 2)")
    cursor.execute("INSERT INTO `cursos` (nome, duracao, id_cidade) VALUES ('Design Gráfico', 24, 3)")

    cursor.execute("INSERT INTO `professores` (nome, especialidade, id_cidade) VALUES ('Fernanda Martins', 'Engenharia', 1)")
    cursor.execute("INSERT INTO `professores` (nome, especialidade, id_cidade) VALUES ('Carlos Santos', 'Administração', 2)")
    cursor.execute("INSERT INTO `professores` (nome, especialidade, id_cidade) VALUES ('Tatiane Lima', 'Design', 3)")

    cursor.execute("INSERT INTO `usuarios` (nome, email, senha, tipo) VALUES ('superadmin', 'admin@escola.com', 'senhaSegura123', 'admin')")
    cursor.execute("INSERT INTO `usuarios` (nome, email, senha, tipo) VALUES ('professorLucas', 'lucas@escola.com', 'senhaProf456', 'professor')")
    cursor.execute("INSERT INTO `usuarios` (nome, email, senha, tipo) VALUES ('alunaJuliana', 'juliana@escola.com', 'senhaAluno789', 'aluno')")

    # Criando as chaves estrangeiras
    cursor.execute("""
        ALTER TABLE `alunos`
        ADD CONSTRAINT `alunos_ibfk_1` FOREIGN KEY (`id_cidade`) REFERENCES `cidades` (`id`)
    """)

    cursor.execute("""
        ALTER TABLE `cursos`
        ADD CONSTRAINT `cursos_ibfk_1` FOREIGN KEY (`id_cidade`) REFERENCES `cidades` (`id`)
    """)

    cursor.execute("""
        ALTER TABLE `professores`
        ADD CONSTRAINT `professores_ibfk_1` FOREIGN KEY (`id_cidade`) REFERENCES `cidades` (`id`)
    """)

    # Commitando as alterações
    conn.commit()
    print("Banco de dados criado e populado com sucesso!")

except mysql.connector.Error as err:
    if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
        print("Usuário ou senha inválidos")
    elif err.errno == errorcode.ER_BAD_DB_ERROR:
        print("Banco de dados não existe")
    else:
        print(err)
finally:
    cursor.close()
    conn.close()
