import tkinter as tk
from tkinter import messagebox


def verificar_login():
    usuario = entry_usuario.get()
    senha = entry_senha.get()

    # Exemplo de verificação
    if usuario == "admin" and senha == "senha123":
        messagebox.showinfo("Login", "Login bem-sucedido!")
        # Aqui você pode redirecionar para outra tela ou função
    else:
        messagebox.showerror("Login", "Usuário ou senha incorretos.")


# Criar a janela principal
janela = tk.Tk()
janela.title("Tela de Login")

# Criar widgets
label_usuario = tk.Label(janela, text="Usuário:")
label_usuario.pack(pady=5)

entry_usuario = tk.Entry(janela)
entry_usuario.pack(pady=5)

label_senha = tk.Label(janela, text="Senha:")
label_senha.pack(pady=5)

entry_senha = tk.Entry(janela, show="*")
entry_senha.pack(pady=5)

botao_login = tk.Button(janela, text="Login", command=verificar_login)
botao_login.pack(pady=20)

# Iniciar o loop da interface
janela.mainloop()
