import tkinter as tk
from tkinter import messagebox
import sqlite3

# Conectar ao banco de dados (para demonstração, estamos usando SQLite)
conn = sqlite3.connect('cursos.db')
cursor = conn.cursor()

# Criar tabela se não existir (baseado na estrutura da tabela `cursos`)
cursor.execute("""
CREATE TABLE IF NOT EXISTS cursos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    duracao INTEGER NOT NULL,
    id_cidade INTEGER
)
""")
conn.commit()

# Função para inserir curso no banco de dados
def inserir_curso():
    nome = entry_nome.get()
    duracao = entry_duracao.get()
    id_cidade = entry_id_cidade.get()

    if nome and duracao.isdigit() and (id_cidade.isdigit() or id_cidade == ""):
        cursor.execute("INSERT INTO cursos (nome, duracao, id_cidade) VALUES (?, ?, ?)",
                       (nome, int(duracao), int(id_cidade) if id_cidade else None))
        conn.commit()
        messagebox.showinfo("Sucesso", "Curso inserido com sucesso!")
        entry_nome.delete(0, tk.END)
        entry_duracao.delete(0, tk.END)
        entry_id_cidade.delete(0, tk.END)
        mostrar_cursos()
    else:
        messagebox.showwarning("Erro", "Por favor, preencha todos os campos corretamente.")

# Função para mostrar os cursos cadastrados
def mostrar_cursos():
    cursor.execute("SELECT * FROM cursos")
    registros = cursor.fetchall()

    # Limpar a listbox antes de exibir
    listbox_cursos.delete(0, tk.END)

    # Inserir cursos na listbox
    for curso in registros:
        listbox_cursos.insert(tk.END, curso)

# Interface gráfica
root = tk.Tk()
root.title("Cadastro de Cursos")

# Widgets para inserir dados
label_nome = tk.Label(root, text="Nome do Curso:")
label_nome.grid(row=0, column=0)
entry_nome = tk.Entry(root)
entry_nome.grid(row=0, column=1)

label_duracao = tk.Label(root, text="Duração (meses):")
label_duracao.grid(row=1, column=0)
entry_duracao = tk.Entry(root)
entry_duracao.grid(row=1, column=1)

label_id_cidade = tk.Label(root, text="ID da Cidade:")
label_id_cidade.grid(row=2, column=0)
entry_id_cidade = tk.Entry(root)
entry_id_cidade.grid(row=2, column=1)

# Botão para inserir curso
button_inserir = tk.Button(root, text="Inserir Curso", command=inserir_curso)
button_inserir.grid(row=3, column=0, columnspan=2)

# Listbox para mostrar cursos cadastrados
listbox_cursos = tk.Listbox(root, width=50)
listbox_cursos.grid(row=4, column=0, columnspan=2)

# Mostrar cursos ao iniciar
mostrar_cursos()

root.mainloop()

# Fechar conexão com banco de dados
conn.close()
